package com.example.dchya24.submission4.support;

public interface FavoriteInterface {
    void setFavoriteData(FavoriteSupport favoriteData);
}

