package com.example.dchya24.submission4.support;

public interface MyAsyncCallback {
    void onPreExecute();
    void onPostExecute(FavoriteSupport favoriteSupport);
}
